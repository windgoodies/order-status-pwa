## วิธี Deploy ไปยัง GitHub Pages

1. สร้าง GitHub Repo ใหม่
2. Push ไฟล์ทั้งหมดจากโฟลเดอร์นี้
3. ไปที่ Settings > Pages > Source: main / root
4. รอสักครู่ เว็บจะออนไลน์ที่:
   https://your-username.github.io/your-repo-name/

## วิธี Deploy ไปยัง Vercel

1. เข้า https://vercel.com แล้วสมัครด้วย GitHub
2. เลือก Repo นี้เพื่อ Deploy
3. ระบบจะสร้างเว็บออนไลน์อัตโนมัติ

หมายเหตุ: อย่าลืมเปลี่ยน URL ของ Google Script ใน `script.js`